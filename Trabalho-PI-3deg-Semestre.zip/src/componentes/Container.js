import Card from "./Card"
import { StyledContainer } from "./estilos/Conteiner.style";

function Container() {

    return (

        <StyledContainer>
            <Card/>
        </StyledContainer>
    )

}

export default Container;