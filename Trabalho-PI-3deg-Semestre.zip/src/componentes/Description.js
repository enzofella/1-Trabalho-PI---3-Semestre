function Description(){

    return <h2>Champions disponiveis</h2>

}

export default Description;