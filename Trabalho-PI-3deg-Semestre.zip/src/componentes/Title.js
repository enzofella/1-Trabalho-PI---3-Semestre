import { Header } from "./estilos/Header.style"


function Title() {
    return (
        <>
            <Header>
                <img src="https://cdn2.steamgriddb.com/icon/882137f311c5728f8e257e56820af92c.png" alt='logoEmpresa' width={150} />
                <div>
                    <h1>League Of Legends</h1>
                </div>
            </Header>
        </>
    )
}

export default Title;