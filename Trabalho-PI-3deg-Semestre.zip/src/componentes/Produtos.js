import { StyledProduto } from "./estilos/Produtos.style";
import Image from "./Image";


function Produtos() {
    const produtos = [
        {
            "id": 1,
            "title": "Akshan",
            "description": "Descrição detalhada de Akshan.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/9e5ea58123ac5a699700eec49f8412af11e563a0-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 2,
            "title": "Aatrox",
            "description": "Descrição detalhada de Aatrox.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/db39563458aa28c3f3aa8990f2c964a0f7645097-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 3,
            "title": "Ashe",
            "description": "Descrição detalhada de Ashe.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/6311d8de67f55496be4886a353372c8da713dade-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 4,
            "title": "Braum",
            "description": "Descrição detalhada de Braum.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/9e0a1f3e48f9b6c7356e5efe17b23383ace41f76-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 5,
            "title": "Darius",
            "description": "Descrição detalhada de Darius.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/f606418621ccec569ab1ec87e1084dfd8e45e5f1-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 6,
            "title": "Graves",
            "description": "Descrição detalhada de Graves.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/b82361d8b1b9a7788dce0c4604cad844bb68a095-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 7,
            "title": "Akali",
            "description": "Descrição detalhada de Akali.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/abbd173df157f943496abb0638add119f753e3b2-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 8,
            "title": "Nidalee",
            "description": "Descrição detalhada de Nidalee.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/32b6045d73da3659586c80a1b043ba3975dc97ed-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 9,
            "title": "Neeko",
            "description": "Descrição detalhada de Neeko.",
            "imageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3st6lA17Iu5IC2unpFWGjqbxBpv18Q2mLR7PnFAjKRxW-7ScIzw8mGOJNy0W2Lk9tX1k&usqp=CAU"
        },
        {
            "id": 10,
            "title": "Fiora",
            "description": "Descrição detalhada de Fiora.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/e76d371dc28d1bc79a3eb66df8597c12354cc69e-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 11,
            "title": "Ahri",
            "description": "Descrição detalhada de Ahri.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/55e7e901b1f69d72804665cfbeb1f4f59c8fa877-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 12,
            "title": "Lucian",
            "description": "Descrição detalhada de Lucian.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/8ed4651535ff27aa19f06215fd608057c218f7e6-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 13,
            "title": "Lux",
            "description": "Descrição detalhada de Lux.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/4238fe90dd74b08a6e8172c31e3b1ae609afb3cd-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 14,
            "title": "Aurora",
            "description": "Descrição detalhada de Aurora.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data/2984fc54c2eccfed432ac8a78e90757b574178c4-418x473.jpg?auto=format&fit=fill&q=80&w=418"
        },
        {
            "id": 15,
            "title": "Briar",
            "description": "Descrição detalhada de Briar.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/8828f92a1ed9c410b5be0a5424f95b3a8f641e5a-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 16,
            "title": "Kayn",
            "description": "Descrição detalhada de Kayn.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/a926bba66a7fe3b1c207b790fd97075939ce58ee-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 17,
            "title": "Elise",
            "description": "Descrição detalhada de Elise.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/9d7c852f03f09bd32aab843a98f3a4c371afa3ba-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 18,
            "title": "Kalista",
            "description": "Descrição detalhada de Kalista.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/2dc0f005113d17259f5a252f673b48195175c6ab-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 19,
            "title": "Evelynn",
            "description": "Descrição detalhada de Evelynn.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/e5cf98936e8b47a7909248518d7737dd610a137b-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        },
        {
            "id": 20,
            "title": "Draven",
            "description": "Descrição detalhada de Draven.",
            "imageUrl": "https://cmsassets.rgpub.io/sanity/images/dsfx7636/game_data_live/374ea4cb505b1288172fd93d92064af5b7cbc298-496x560.jpg?auto=format&fit=fill&q=80&w=457"
        }]

    return (
        produtos.map((produtos) => {
            return (

                <StyledProduto key={produtos.id}>
                    <Image url={produtos.imageUrl} id={produtos.id} />
                    <p>{produtos.title}</p>
                    <p>{produtos.description}</p>
                </StyledProduto>

            )
        }
        )
    )

}

export default Produtos;