import styled from 'styled-components'

export const Header = styled.div`
background: gray;
color: white;
padding: 0.25em 1em;

& img{border-radius: 35px;}
`